# Machine Learning-Based Intrusion Detection System (IDS)

## Overview
This project implements a real-time Intrusion Detection System (IDS) that leverages Machine Learning (ML) to identify and classify network-based threats. By integrating Scapy for high-fidelity packet capture and flow-based feature extraction with advanced classifiers (XGBoost, Random Forest), the system provides an automated solution for monitoring network traffic and identifying malicious activities such as SYN floods, UDP floods, and unauthorized scanning.

## Key Components

### 1. Packet Acquisition and Flow Tracking
The system captures live network traffic using Scapy. Unlike simple packet-by-packet analysis, this IDS employs a stateful flow tracking mechanism. It groups related packets into flows based on the 5-tuple (source IP, destination IP, source port, destination port, and protocol).

### 2. Feature Extraction
For each network flow, the system extracts 41 quantitative features, including:
- Temporal metrics (Flow Duration, Inter-Arrival Times)
- Volumetric statistics (Total Packets, Total Bytes)
- Statistical measures (Packet Length Mean/Std Dev, IAT Mean/Std Dev)
- Protocol-specific flags and window sizes

### 3. Classification Engine
The classification layer utilizes trained models to perform binary classification (Normal vs. Malicious). The system is optimized for high-performance inference, supporting models trained on extensive datasets (e.g., CICIDS-2017) and exported via Joblib.

### 4. Monitoring Interface
A Graphical User Interface (GUI) developed in PyQt5 provides real-time visualization of network activity, including:
- Live packet feed with protocol-specific color coding.
- Statistical breakdown of traffic types and detection rates.
- An alert log for immediate notification of detected threats.
- Historical data export in CSV format for forensic analysis.

## Technical Specifications
- **Programming Language:** Python 3.9+
- **Network Library:** Scapy
- **ML Frameworks:** XGBoost, Scikit-Learn
- **GUI Framework:** PyQt5
- **Data Handling:** NumPy, Pandas

## Project Architecture
```
IDS-Project/
├── main.py                   # Application entry point
├── install_requirements.py   # Dependency installation script
├── requirements.txt          # Python dependencies
├── ids/                      # Core IDS implementation
│   ├── sniffer.py            # Packet capture engine
│   ├── feature_extractor.py  # Flow-based feature extraction
│   ├── classifier.py         # ML inference engine
│   └── utils.py              # Constants and logging utilities
├── gui/                      # User Interface components
│   ├── main_window.py        # Main application dashboard
│   ├── packet_table.py       # Live data table widget
│   └── stats_panel.py        # Statistics and metrics panel
├── models/                   # Serialized ML model directory
└── usage.md                  # Detailed operational instructions
```
