"""Simplified stats panel."""
from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel

class StatsPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.counts = {"Normal": 0, "Malicious": 0}
        self.protocols = {}
        
        self.layout = QVBoxLayout(self)
        self.title = QLabel("Traffic Statistics")
        self.title.setStyleSheet("font-weight: bold; font-size: 14px;")
        self.layout.addWidget(self.title)
        
        self.normal_lbl = QLabel("Normal: 0")
        self.malicious_lbl = QLabel("Malicious: 0")
        self.layout.addWidget(self.normal_lbl)
        self.layout.addWidget(self.malicious_lbl)
        
        self.proto_lbl = QLabel("Protocols: -")
        self.layout.addWidget(self.proto_lbl)
        self.layout.addStretch()

    def update_stats(self, label, proto):
        self.counts[label] = self.counts.get(label, 0) + 1
        self.protocols[proto] = self.protocols.get(proto, 0) + 1
        
        self.normal_lbl.setText(f"Normal: {self.counts['Normal']}")
        self.malicious_lbl.setText(f"Malicious: {self.counts['Malicious']}")
        
        proto_str = ", ".join([f"{k}: {v}" for k, v in self.protocols.items()])
        self.proto_lbl.setText(f"Protocols: {proto_str}")
