"""Shared utilities and constants."""
import logging
import os

# --- Logging ---
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s]: %(message)s")
logger = logging.getLogger("IDS")

# --- Paths ---
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(ROOT_DIR, "models")
SCALER_PATH = os.path.join(ROOT_DIR, "RobustScalerDf.pkl")
DEFAULT_MODEL = os.path.join(MODELS_DIR, "model_xgb.pkl")

# --- Constants ---
FEATURE_NAMES = [
    "Protocol", "Flow Duration", "Tot Fwd Pkts", "Tot Bwd Pkts", "TotLen Bwd Pkts",
    "Fwd Pkt Len Max", "Fwd Pkt Len Min", "Fwd Pkt Len Mean", "Bwd Pkt Len Max",
    "Bwd Pkt Len Min", "Bwd Pkt Len Mean", "Flow Byts/s", "Flow Pkts/s",
    "Flow IAT Mean", "Flow IAT Std", "Flow IAT Max", "Flow IAT Min",
    "Fwd IAT Tot", "Fwd IAT Mean", "Fwd IAT Std", "Fwd IAT Max", "Fwd IAT Min",
    "Bwd IAT Tot", "Bwd IAT Mean", "Bwd IAT Std", "Bwd IAT Max", "Bwd IAT Min",
    "Fwd Pkts/s", "Bwd Pkts/s", "Pkt Len Min", "Pkt Len Mean", "Pkt Len Std",
    "Pkt Len Var", "Init Bwd Win Byts", "Active Mean", "Active Std", "Active Min",
    "Idle Mean", "Idle Std", "Packets_per_Second", "Bytes_per_Second", "Avg_Packet_Size"
]

LABEL_MAP = {0: "Normal", 1: "Malicious"}
