"""Simplified packet table."""
from PyQt5.QtWidgets import QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt

class PacketTable(QTableWidget):
    def __init__(self, parent=None):
        columns = ["Time", "Source IP", "Destination IP", "Protocol", "Length", "Label", "Confidence"]
        super().__init__(0, len(columns), parent)
        self.setHorizontalHeaderLabels(columns)
        self.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.verticalHeader().setVisible(False)
        self.setEditTriggers(QTableWidget.NoEditTriggers)

    def add_packet(self, time_str, src_ip, dst_ip, proto, length, label, conf):
        row = self.rowCount()
        self.insertRow(row)
        
        items = [time_str, src_ip, dst_ip, proto, str(length), label, f"{conf:.1%}"]
        for col, text in enumerate(items):
            item = QTableWidgetItem(text)
            item.setTextAlignment(Qt.AlignCenter)
            self.setItem(row, col, item)
        
        # Keep only last 50 rows for performance
        if self.rowCount() > 50:
            self.removeRow(0)
        
        self.scrollToBottom()
