import os
import joblib
import pandas as pd
import numpy as np
from ids.utils import logger, LABEL_MAP, SCALER_PATH, DEFAULT_MODEL, FEATURE_NAMES

class PacketClassifier:
    def __init__(self, threshold=0.30):
        self.model = None
        self.scaler = None
        self.threshold = threshold
        self._load_assets()

    def _load_assets(self):
        try:
            if os.path.exists(SCALER_PATH):
                self.scaler = joblib.load(SCALER_PATH)

            if os.path.exists(DEFAULT_MODEL):
                self.model = joblib.load(DEFAULT_MODEL)
                if hasattr(self.model, "set_params"):
                    self.model.set_params(n_jobs=1)
                logger.info("XGBoost model and Scaler loaded.")
            else:
                logger.error(f"Model not found at {DEFAULT_MODEL}")
        except Exception as e:
            logger.error(f"Error loading model/scaler: {e}")

    def predict(self, features: np.ndarray) -> dict:
        if self.model is None:
            return {
                "label": "Normal",
                "confidence": 0.0,
                "attack_prob": 0.0,
                "threshold": self.threshold
            }

        try:
            df = pd.DataFrame([features], columns=FEATURE_NAMES)

            if self.scaler is not None:
                X = self.scaler.transform(df)
            else:
                X = df.values

            if hasattr(self.model, "predict_proba"):
                probs = self.model.predict_proba(X)[0]
                attack_prob = float(probs[1])
                normal_prob = float(probs[0])

                label = "Malicious" if attack_prob >= self.threshold else "Normal"
                confidence = attack_prob if label == "Malicious" else normal_prob

                return {
                    "label": label,
                    "confidence": confidence,
                    "attack_prob": attack_prob,
                    "threshold": self.threshold
                }

            prediction = int(self.model.predict(X)[0])
            return {
                "label": LABEL_MAP.get(prediction, "Unknown"),
                "confidence": 0.0,
                "attack_prob": 0.0,
                "threshold": self.threshold
            }

        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return {
                "label": "Error",
                "confidence": 0.0,
                "attack_prob": 0.0,
                "threshold": self.threshold
            }