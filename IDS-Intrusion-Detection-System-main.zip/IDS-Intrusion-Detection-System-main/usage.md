# Operational Instructions

This document provides detailed guidance on the installation, configuration, and operation of the Intrusion Detection System (IDS).

## Prerequisites

### 1. Network Driver Requirements
- **Windows:** You must install **Npcap** (available at [https://npcap.com/](https://npcap.com/)). Ensure the "Install Npcap in WinPcap API-compatible Mode" option is selected during installation.
- **Linux:** Scapy requires root privileges to access raw sockets for packet capture.

### 2. Python Environment
The project requires Python 3.9 or higher. It is recommended to use a virtual environment for dependency management.

## Installation

1. **Install Dependencies:**
   Run the provided installation script to install all necessary Python libraries:
   ```bash
   python install_requirements.py
   ```

2. **Required Files:**
   Ensure the following files are present in the project root directory:
   - `RobustScalerDf.pkl`: The fitted scaler used during training.
   - `models/`: Directory containing your trained `.pkl` models (e.g., `model_xgb.pkl`).

## Operation

### 1. Launching the Application
- **Windows:**
  ```bash
  python main.py
  ```
- **Linux/macOS:**
  ```bash
  sudo python main.py
  ```

### 2. Configuration via GUI
- **Interface Selection:** Select the appropriate network adapter from the "Network Adapter" dropdown.
- **Model Selection:** Choose the desired ML model from the "Detection Model" dropdown. The system will automatically apply the Robust Scaler to live traffic features.

### 3. Monitoring and Data Export
- Click **Start Capture** to begin real-time monitoring.
- The system extracts 42 numerical features from live flows, scales them, and performs binary classification.
- Malicious activities will trigger alerts in the "Alert Log".
- Click **Export CSV** to save results for forensic analysis.

## Technical Details
The system utilizes a 42-dimension feature vector synchronized with the research notebook. This includes temporal metrics, volumetric statistics, and protocol flags. All live data is normalized using the `RobustScaler` to ensure consistency with the training environment.
