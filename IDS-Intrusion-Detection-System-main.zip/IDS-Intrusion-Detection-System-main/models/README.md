# Model Directory

This directory is designated for the storage of serialized machine learning models utilized by the Intrusion Detection System.

## Guidelines for Model Integration

To integrate a custom-trained model into the system, please adhere to the following specifications:

1.  **Format:** Models must be serialized using the `joblib` library and saved with a `.pkl` extension.
2.  **Compatibility:** The model must be trained to accept a 41-dimension input vector, corresponding to the features extracted by the system's `FlowTracker` module (e.g., Protocol, Flow Duration, Packet Length statistics).
3.  **Deployment:** Place the `.pkl` file directly within this directory. The IDS application will dynamically detect and list all compatible models in the user interface during startup.

For detailed information on the feature vector and extraction methodology, refer to the main project documentation.
