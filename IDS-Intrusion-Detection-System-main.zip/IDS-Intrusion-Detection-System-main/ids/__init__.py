"""IDS core package."""
