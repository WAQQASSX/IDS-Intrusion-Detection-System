"""
Extract flow-based features from network packets.
These 42 features are used by the ML model to distinguish between Normal and Malicious traffic.
"""
from __future__ import annotations
import numpy as np
from typing import Dict, Tuple

try:
    from scapy.layers.inet import IP, TCP, UDP, ICMP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

class Flow:
    """Represents a network flow (bidirectional traffic between two endpoints)."""
    def __init__(self, first_pkt, protocol: int):
        self.protocol = protocol
        self.start_time = float(first_pkt.time)
        self.last_time = float(first_pkt.time)
        
        self.fwd_pkts = 0
        self.bwd_pkts = 0
        self.fwd_bytes = 0
        self.bwd_bytes = 0
        self.fwd_pkt_lens = []
        self.bwd_pkt_lens = []
        self.all_iats = []
        self.fwd_last_time = None
        self.bwd_last_time = None
        self.fwd_iats = []
        self.bwd_iats = []
        self.init_bwd_win_byts = 0
        
        # For Active/Idle time calculation
        self.active_start = float(first_pkt.time)
        self.idle_times = []
        self.active_times = []

    def update(self, pkt, direction: str):
        curr_time = float(pkt.time)
        pkt_len = len(pkt)
        iat = curr_time - self.last_time
        self.all_iats.append(iat)
        
        # If gap between packets > 1s, consider it an idle period
        if iat > 1.0:
            self.idle_times.append(iat)
            self.active_times.append(self.last_time - self.active_start)
            self.active_start = curr_time
        
        if direction == "fwd":
            self.fwd_pkts += 1
            self.fwd_bytes += pkt_len
            self.fwd_pkt_lens.append(pkt_len)
            if self.fwd_last_time is not None:
                self.fwd_iats.append(curr_time - self.fwd_last_time)
            self.fwd_last_time = curr_time
        else:
            self.bwd_pkts += 1
            self.bwd_bytes += pkt_len
            self.bwd_pkt_lens.append(pkt_len)
            if self.bwd_last_time is not None:
                self.bwd_iats.append(curr_time - self.bwd_last_time)
            if self.bwd_pkts == 1 and pkt.haslayer(TCP):
                self.init_bwd_win_byts = pkt[TCP].window
            self.bwd_last_time = curr_time
            
        self.last_time = curr_time

    def get_features(self) -> np.ndarray:
        """Calculate the final 42 features for this flow."""
        duration = self.last_time - self.start_time
        if duration <= 0: duration = 1.0 
            
        fwd_lens = np.array(self.fwd_pkt_lens) if self.fwd_pkt_lens else np.array([0])
        bwd_lens = np.array(self.bwd_pkt_lens) if self.bwd_pkt_lens else np.array([0])
        all_lens = np.concatenate([fwd_lens, bwd_lens])
        
        fwd_iats = np.array(self.fwd_iats) if self.fwd_iats else np.array([0])
        bwd_iats = np.array(self.bwd_iats) if self.bwd_iats else np.array([0])
        all_iats = np.array(self.all_iats) if self.all_iats else np.array([0])
        
        current_active = self.last_time - self.active_start
        active_np = np.array(self.active_times + [current_active])
        idle_np = np.array(self.idle_times) if self.idle_times else np.array([0])

        features = [
            self.protocol, duration, self.fwd_pkts, self.bwd_pkts, self.bwd_bytes,
            np.max(fwd_lens), np.min(fwd_lens), np.mean(fwd_lens),
            np.max(bwd_lens), np.min(bwd_lens), np.mean(bwd_lens),
            (self.fwd_bytes + self.bwd_bytes) / duration, # Flow Byts/s
            (self.fwd_pkts + self.bwd_pkts) / duration,   # Flow Pkts/s
            np.mean(all_iats), np.std(all_iats), np.max(all_iats), np.min(all_iats),
            np.sum(fwd_iats), np.mean(fwd_iats), np.std(fwd_iats), np.max(fwd_iats), np.min(fwd_iats),
            np.sum(bwd_iats), np.mean(bwd_iats), np.std(bwd_iats), np.max(bwd_iats), np.min(bwd_iats),
            self.fwd_pkts / duration, # Fwd Pkts/s
            self.bwd_pkts / duration, # Bwd Pkts/s
            np.min(all_lens), np.mean(all_lens), np.std(all_lens), np.var(all_lens),
            self.init_bwd_win_byts,
            np.mean(active_np), np.std(active_np), np.min(active_np),
            np.mean(idle_np), np.std(idle_np),
            self.fwd_pkts / duration,      # Packets_per_Second
            self.fwd_bytes / duration,     # Bytes_per_Second
            self.fwd_bytes / (self.fwd_pkts + 1), # Avg_Packet_Size
        ]
        return np.array(features, dtype=np.float32)

class FlowTracker:
    """Tracks active flows and updates them with new packets."""
    def __init__(self):
        self.flows: Dict[Tuple, Flow] = {}

    def get_flow_features(self, pkt) -> np.ndarray | None:
        if not pkt.haslayer(IP): return None
            
        ip = pkt[IP]
        proto = int(ip.proto)
        src_ip, dst_ip = ip.src, ip.dst
        src_port, dst_port = 0, 0
        
        if pkt.haslayer(TCP):
            src_port, dst_port = pkt[TCP].sport, pkt[TCP].dport
        elif pkt.haslayer(UDP):
            src_port, dst_port = pkt[UDP].sport, pkt[UDP].dport

        # Identify flow by 5-tuple
        fwd_key = (src_ip, dst_ip, src_port, dst_port, proto)
        bwd_key = (dst_ip, src_ip, dst_port, src_port, proto)
        
        if fwd_key in self.flows:
            flow = self.flows[fwd_key]
            flow.update(pkt, "fwd")
        elif bwd_key in self.flows:
            flow = self.flows[bwd_key]
            flow.update(pkt, "bwd")
        else:
            flow = Flow(pkt, proto)
            flow.update(pkt, "fwd")
            self.flows[fwd_key] = flow
            
        return flow.get_features()

# Singleton tracker instance
tracker = FlowTracker()

def reset_tracker():
    global tracker
    tracker = FlowTracker()

def extract_features(pkt) -> np.ndarray | None:
    """Interface for the rest of the application."""
    if not SCAPY_AVAILABLE: return None
    return tracker.get_flow_features(pkt)
