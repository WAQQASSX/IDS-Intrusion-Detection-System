"""Load XGBoost model and classify packets."""
import os
import joblib
import pandas as pd
import numpy as np
from ids.utils import logger, LABEL_MAP, SCALER_PATH, DEFAULT_MODEL, FEATURE_NAMES

class PacketClassifier:
    def __init__(self):
        self.model = None
        self.scaler = None
        self._load_assets()

    def _load_assets(self):
        """Load the RobustScaler and the XGBoost model."""
        try:
            if os.path.exists(SCALER_PATH):
                self.scaler = joblib.load(SCALER_PATH)
            
            if os.path.exists(DEFAULT_MODEL):
                self.model = joblib.load(DEFAULT_MODEL)
                # Ensure CPU usage for simple inference
                if hasattr(self.model, "set_params"):
                    self.model.set_params(n_jobs=1)
                logger.info("XGBoost model and Scaler loaded.")
            else:
                logger.error(f"Model not found at {DEFAULT_MODEL}")
        except Exception as e:
            logger.error(f"Error loading model/scaler: {e}")

    def predict(self, features: np.ndarray) -> dict:
        """Predict if a packet flow is Normal or Malicious."""
        if self.model is None:
            return {"label": "Normal", "confidence": 0.0}

        try:
            # Convert to DataFrame for scaling
            df = pd.DataFrame([features], columns=FEATURE_NAMES)
            
            if self.scaler:
                X = self.scaler.transform(df)
            else:
                X = df.values

            prediction = int(self.model.predict(X)[0])
            confidence = 0.0
            
            if hasattr(self.model, "predict_proba"):
                confidence = float(self.model.predict_proba(X)[0][prediction])

            return {
                "label": LABEL_MAP.get(prediction, "Unknown"),
                "confidence": confidence
            }
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return {"label": "Error", "confidence": 0.0}
