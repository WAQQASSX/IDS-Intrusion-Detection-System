"""Capture packets using Scapy in a background thread."""
import threading
from scapy.all import sniff, conf

class PacketSniffer:
    def __init__(self, interface, callback):
        self.interface = interface
        self.callback = callback
        self.stop_event = threading.Event()
        self.thread = None

    def start(self):
        self.stop_event.clear()
        self.thread = threading.Thread(target=self._run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=1)

    def _run(self):
        """
        Capture all packets (Inbound and Outbound) on the interface.
        Promiscuous mode is enabled to see all traffic on the segment.
        """
        try:
            # Global Scapy settings for better capture on Windows
            conf.sniff_promisc = True 
            
            # Use sniff with explicit interface and promiscuous mode
            sniff(
                iface=self.interface,
                prn=self.callback,
                stop_filter=lambda _: self.stop_event.is_set(),
                store=False,
                promisc=True # Forces the adapter to pass all traffic to the OS
            )
        except Exception as e:
            print(f"Sniffer Error: {e}")

def list_interfaces():
    """List available network interfaces."""
    interfaces = []
    # Scapy's conf.ifaces is a dict-like object containing all adapters
    for iface in conf.ifaces.values():
        interfaces.append({
            "name": iface.name,
            "ip": iface.ip if iface.ip else "No IP",
            "description": iface.description if iface.description else iface.name
        })
    return interfaces
