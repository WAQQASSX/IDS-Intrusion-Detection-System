"""Main GUI for the IDS - Simplified for Viva."""
import sys
import datetime
from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QLabel, QComboBox, QPushButton, QTextEdit, QStatusBar
)
from PyQt5.QtCore import Qt, pyqtSignal, QObject
from ids.sniffer import PacketSniffer, list_interfaces
from ids.feature_extractor import extract_features, reset_tracker
from ids.classifier import PacketClassifier
from gui.packet_table import PacketTable
from gui.stats_panel import StatsPanel

class PacketSignal(QObject):
    new_packet = pyqtSignal(dict)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Simple Machine Learning IDS (XGBoost)")
        self.resize(1000, 700)
        
        self.classifier = PacketClassifier()
        self.sniffer = None
        self.signal = PacketSignal()
        self.signal.new_packet.connect(self._on_packet)
        
        self._init_ui()
        self._load_interfaces()

    def _init_ui(self):
        central = QWidget()
        layout = QVBoxLayout(central)
        
        # Top Controls
        top_layout = QHBoxLayout()
        top_layout.addWidget(QLabel("Select Interface:"))
        self.iface_combo = QComboBox()
        top_layout.addWidget(self.iface_combo)
        
        self.start_btn = QPushButton("Start Detection")
        self.start_btn.clicked.connect(self.start_capture)
        top_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self.stop_capture)
        top_layout.addWidget(self.stop_btn)
        
        layout.addLayout(top_layout)
        
        # Main Display (Table and Stats)
        main_layout = QHBoxLayout()
        self.table = PacketTable()
        main_layout.addWidget(self.table, 3)
        
        side_layout = QVBoxLayout()
        self.stats = StatsPanel()
        side_layout.addWidget(self.stats)
        
        side_layout.addWidget(QLabel("Alert Log:"))
        self.alert_log = QTextEdit()
        self.alert_log.setReadOnly(True)
        self.alert_log.setStyleSheet("background: black; color: red; font-family: monospace;")
        side_layout.addWidget(self.alert_log)
        
        main_layout.addLayout(side_layout, 1)
        layout.addLayout(main_layout)
        
        self.setCentralWidget(central)
        self.status = QStatusBar()
        self.setStatusBar(self.status)
        self.status.showMessage("Ready.")

    def _load_interfaces(self):
        for iface in list_interfaces():
            self.iface_combo.addItem(f"{iface['description']} ({iface['ip']})", iface['name'])

    def start_capture(self):
        iface = self.iface_combo.currentData()
        if not iface: return
        
        reset_tracker()
        self.sniffer = PacketSniffer(iface, lambda pkt: self.signal.new_packet.emit(self._process_packet(pkt)))
        self.sniffer.start()
        
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.status.showMessage(f"Monitoring traffic on {iface}...")

    def stop_capture(self):
        if self.sniffer:
            self.sniffer.stop()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.status.showMessage("Monitoring stopped.")

    def _process_packet(self, pkt):
        """Extract features and predict."""
        from scapy.layers.inet import IP, TCP, UDP, ICMP
        
        info = {
            "time": datetime.datetime.now().strftime("%H:%M:%S"),
            "src": "-", "dst": "-", "proto": "OTHER",
            "len": len(pkt), "label": "Normal", "conf": 0.0
        }
        
        if pkt.haslayer(IP):
            info["src"] = pkt[IP].src
            info["dst"] = pkt[IP].dst
            if pkt.haslayer(TCP): info["proto"] = "TCP"
            elif pkt.haslayer(UDP): info["proto"] = "UDP"
            elif pkt.haslayer(ICMP): info["proto"] = "ICMP"
            
            features = extract_features(pkt)
            if features is not None:
                res = self.classifier.predict(features)
                info["label"] = res["label"]
                info["conf"] = res["confidence"]
        
        return info

    def _on_packet(self, info):
        self.table.add_packet(
            info["time"], info["src"], info["dst"], 
            info["proto"], info["len"], info["label"], info["conf"]
        )
        self.stats.update_stats(info["label"], info["proto"])
        
        if info["label"] == "Malicious":
            self.alert_log.append(f"[{info['time']}] ALERT: {info['src']} -> Malicious Activity Detected!")

    def closeEvent(self, event):
        self.stop_capture()
        super().closeEvent(event)
