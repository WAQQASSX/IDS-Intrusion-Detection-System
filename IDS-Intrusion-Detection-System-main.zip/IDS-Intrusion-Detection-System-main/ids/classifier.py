import os
import joblib
import pandas as pd
import numpy as np
from ids.utils import logger, LABEL_MAP, SCALER_PATH, DEFAULT_MODEL, FEATURE_NAMES

class PacketClassifier:
    def __init__(self):
        self.model = None
        self.scaler = None
        self.threshold = 0.65
        self._load_assets()

    def _load_assets(self):
        try:
            if os.path.exists(SCALER_PATH):
                self.scaler = joblib.load(SCALER_PATH)

            if os.path.exists(DEFAULT_MODEL):
                self.model = joblib.load(DEFAULT_MODEL)
                if hasattr(self.model, "set_params"):
                    self.model.set_params(n_jobs=1)
                logger.info("XGBoost model and Scaler loaded.")
            else:
                logger.error(f"Model not found at {DEFAULT_MODEL}")
        except Exception as e:
            logger.error(f"Error loading model/scaler: {e}")

    def predict(self, features: np.ndarray) -> dict:
        if self.model is None:
            return {"label": "Normal", "confidence": 0.0, "attack_prob": 0.0, "threshold": self.threshold}

        try:
            df = pd.DataFrame([features], columns=FEATURE_NAMES)

            if self.scaler:
                X = self.scaler.transform(df)
            else:
                X = df.values

            proba = self.model.predict_proba(X)[0]
            attack_prob = float(proba[1])

            prediction = 1 if attack_prob >= self.threshold else 0
            confidence = attack_prob if prediction == 1 else float(proba[0])

            return {
                "label": LABEL_MAP.get(prediction, "Unknown"),
                "confidence": confidence,
                "attack_prob": attack_prob,
                "threshold": self.threshold
            }

        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return {"label": "Error", "confidence": 0.0, "attack_prob": 0.0, "threshold": self.threshold}